from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import os


class Signup():
    def __init__(self,root):
        self.root=root
        self.root.title("Employee management system")
        self.root.geometry("2080x1140")
        self.root.config(background="silver")




        Frame1 = Frame(self.root, bd=12, relief=RAISED)
        Frame1.place(x=10 ,y=100, height=600, width=900)

        Frame2 = Frame(self.root, bd=10, relief=GROOVE, width=500, height=600)
        Frame2.place(x=1000, y=100)



        self.employeename = StringVar()
        self.idnumber = StringVar()
        self.address = StringVar()
        self.department = StringVar()
        self.age = StringVar()
        self.experiencedfields = StringVar()
        self.dateofbirth = StringVar()

        signup = Label(self.root, text="Registration Page", font=("times new roman", 35, "bold"), fg="black",pady=9 ,bg="silver",bd=10,relief=GROOVE)
        signup.pack(fill=X)

        utsav = Label(Frame1, text="Employee Details", font=("times new roman", 20, "bold underline"), fg="black", pady=9
                       , bd=10)
        utsav.grid(row=0,columnspan=4)

        employee = Label(Frame1, text="Employee Name:", font=("times new roman", 15, "bold"), fg="black",
                        )
        employee.grid(row=1,column=0,padx=15)

        textemployee = Entry(Frame1, width=25, bg="gray",relief=GROOVE,textvariable=self.employeename)
        textemployee.grid(row=1, column=1,padx=20)

        employeeid = Label(Frame1, text="ID number:", font=("times new roman", 15, "bold"), fg="black",
                         )
        employeeid.grid(row=1, column=2, padx=15)

        textid = Entry(Frame1, width=25, bg="gray", relief=GROOVE,textvariable=self.idnumber)
        textid.grid(row=1, column=3, padx=20)

        employeeadd= Label(Frame1, text="Address:", font=("times new roman", 15, "bold"), fg="black",
                           )
        employeeadd.grid(row=2, column=0, padx=15,pady=15)

        textadd= Entry(Frame1, width=25, bg="gray", relief=GROOVE,textvariable=self.address)
        textadd.grid(row=2, column=1, padx=20,pady=15)

        employeedob= Label(Frame1, text="Date of birth:", font=("times new roman", 15, "bold"), fg="black",
                            )
        employeedob.grid(row=2, column=2, padx=15, pady=15)

        textdob = Entry(Frame1, width=25, bg="gray", relief=GROOVE,textvariable=self.dateofbirth)
        textdob.grid(row=2, column=3, padx=20, pady=15)

        employeeage = Label(Frame1, text="Age:", font=("times new roman", 15, "bold"), fg="black",
                            )
        employeeage.grid(row=3, column=0, padx=15, pady=15)

        textage = Entry(Frame1, width=25, bg="gray", relief=GROOVE,textvariable=self.age)
        textage.grid(row=3, column=1, padx=20, pady=15)

        employeepre = Label(Frame1, text="Experienced Field:", font=("times new roman", 15, "bold"), fg="black",
                            )
        employeepre.grid(row=3, column=2, padx=15, pady=10)

        textpre= Entry(Frame1, width=25, bg="gray", relief=GROOVE,textvariable=self.experiencedfields)
        textpre.grid(row=3, column=3, padx=20, pady=10)

        utsav1 = Label(Frame1, text="Department Details", font=("times new roman", 20, "bold underline"), fg="black",
                      pady=9 , bd=10)

        utsav1.grid(row=4, columnspan=4)

        department= Label(Frame1, text="Department name:", font=("times new roman", 15, "bold"), fg="black",
                            )
        department.grid(row=5, column=0, padx=15, pady=10)

        departmenttxt=ttk.Combobox(Frame1,width=25,state="readonly")
        departmenttxt['values']=("Academic","Teacher","Administration","staff")
        departmenttxt.grid(row=5,column=1,padx=20,pady=20)

        departmentcode = Label(Frame1, text="Department code:", font=("times new roman", 15, "bold"), fg="black",
                           )
        departmentcode.grid(row=6, column=0, padx=15, pady=10)

        txtdepcode= Entry(Frame1, width=25, bg="gray", relief=GROOVE,textvariable=self.department)
        txtdepcode.grid(row=6, column=1, padx=20, pady=10)

        button5 = Button(Frame1, text="Register", width=12, height=2, bg="gray", fg="blue", activeforeground="white",
                         activebackground="green",command=self.savefile)
        button5.grid(row=7, column=1,padx=20,pady=40)

        button6 = Button(Frame1, text="exit", width=12, height=2, bg="gray", fg="blue", activeforeground="white",
                         activebackground="red", command=self.exit)
        button6.grid(row=7, column=3,pady=40)

        button7 = Button(Frame1, text="reset", width=12, height=2, bg="gray", fg="blue", activeforeground="white",
                         activebackground="red",command=self.fun)
        button7.grid(row=7, column=2,pady=40)

    def fun(self):



        self.employeename.set("")
        self.address.set("")
        self.idnumber.set("")
        self.department.set("")
        self.age.set("")
        self.dateofbirth.set("")
        self.experiencedfields.set("")





    def exit(self):
        option=messagebox.askokcancel("QUIT","Do you really want to quit?")
        if option>0:
            self.root.destroy()
        else:
            return


    def savefile(self):
        if (self.employeename.get()==""):
            messagebox.showerror("ERROR"," All information required")
        elif(self.dateofbirth.get()==""):
            messagebox.showerror("ERROR", " All information required")
        elif(self.age.get()==""):
            messagebox.showerror("ERROR", " All information required")
        elif(self.address.get()==""):
            messagebox.showerror("ERROR", " All information required")
        elif(self.department.get()==""):
            messagebox.showerror("ERROR", " All information required")
        elif(self.experiencedfields.get()==""):
            messagebox.showerror("ERROR", " All information required")


        else:
            f=open("files/"+str(self.employeename.get())+".txt","w")
            f.write(str(self.employeename.get())+","+
                    str(self.idnumber.get()) + "," +
                    str(self.age.get()) + "," +
                    str(self.address.get()) + "," +
                    str(self.department.get()) + "," +
                    str(self.experiencedfields.get()) + "," +
                    str(self.dateofbirth.get())
                    )
            f.close()
            messagebox.showinfo("SUCCECSS","Sucessfully saved")









root=Tk()
object=Signup(root)
root.mainloop()


scroll_y = Scrollbar(frame6, orient=VERTICAL)
            self.file_list = Listbox(frame6, yscrollcommand=scroll_y.set)
            scroll_y.place(x=955, y=115, height=505)
            scroll_y.config(command=self.file_list.yview)
            self.file_list.place(x=955, y=112, height=502, width=369)
            self.show_files()